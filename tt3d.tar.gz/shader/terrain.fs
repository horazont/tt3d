uniform float waterLine;
uniform float snowLine;
uniform sampler2D colorMap;

varying vec3 normal;
varying vec3 tangent;
varying vec3 position;
varying vec3 untransformed;

void main()
{
  vec3 lightDir = gl_LightSource[0].position.xyz;
  vec4 lighting = gl_FrontLightProduct[0].ambient;
  
  float heightcoord = ((untransformed.z - waterLine) / (snowLine - waterLine)) * 4.0 / 3.0 - 0.25;
  
  vec3 diffuse = texture2D(colorMap, vec2(heightcoord, 1.0)).rgb;
  
  lighting += gl_LightSource[0].diffuse * vec4(diffuse, 1.0) * max(dot(normalize(normal), lightDir), 0.0);
  gl_FragColor = vec4(vec3(lighting), 1.0);
}
